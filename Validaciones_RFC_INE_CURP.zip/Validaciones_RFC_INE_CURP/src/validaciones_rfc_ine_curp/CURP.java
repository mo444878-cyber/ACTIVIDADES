/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package validaciones_rfc_ine_curp;
import java.time.LocalDate;
import java.time.DateTimeException;
import java.util.Set;
import java.util.HashSet;
import java.util.regex.Pattern;
/**
 *
 * @author luis-
 */
public class CURP {
    private static final Pattern FORMATO_CURP =
            Pattern.compile("^[A-ZÑ][AEIOU][A-ZÑ]{2}\\d{6}[HM][A-Z]{2}[B-DF-HJ-NP-TV-ZÑ]{3}[A-Z0-9]{2}$");

    private static final Set<String> ENTIDADES = new HashSet<>();

    static {
        String[] lista = {
            "AS","BC","BS","CC","CL","CM","CS","CH","DF","DG",
            "GT","GR","HG","JC","MC","MN","MS","NT","NL","OC",
            "PL","QT","QR","SP","SL","SR","TC","TS","TL","VZ",
            "YN","ZS","NE"
        };

        for (String e : lista) {
            ENTIDADES.add(e);
        }
    }

    public static boolean validarCURP(String texto) {

        if (texto == null)
            return false;

        String valor = texto.strip().toUpperCase();

        if (valor.length() != 18)
            return false;

        if (!FORMATO_CURP.matcher(valor).matches())
            return false;

        try {

            int anio = Integer.parseInt(valor.substring(4, 6));
            int mes  = Integer.parseInt(valor.substring(6, 8));
            int dia  = Integer.parseInt(valor.substring(8, 10));

            int anioReal = (anio <= 26) ? anio + 2000 : anio + 1900;

            LocalDate.of(anioReal, mes, dia);

       } catch (NumberFormatException | DateTimeException ex) {
            return false;
        }

        String claveEstado = valor.substring(11, 13);

        if (!ENTIDADES.contains(claveEstado))
            return false;

        return true;
    }
}
